import 'package:flutter/material.dart';
import '../models/user.dart';
import '../models/mission.dart';
import '../services/api_service.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Future<User> userFuture;
  late Future<List<Mission>> missionsFuture;

  @override
  void initState() {
    super.initState();
    userFuture = ApiService.fetchUser(1); // Ganti 1 dengan ID user sesuai backend
    missionsFuture = ApiService.fetchMissions();
    print(missionsFuture);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder(
        future: Future.wait([userFuture, missionsFuture]),
        builder: (context, AsyncSnapshot<List<dynamic>> snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            print('Error: ${snapshot.error}');
            return Center(child: Text('Error: ${snapshot.error}'));
          } else {
            User user = snapshot.data![0];
            
            List<Mission> missions = snapshot.data![1];
            
            int completedMissions = user.missions.where((m) => m.isCompleted).length;

            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Halo ${user.username}!',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('$completedMissions/${missions.length} Misi Telah Dikerjakan'),
                      Text('Poin: ${user.points}', style: TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                  SizedBox(height: 16),
                  Text('Misi Hari Ini', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  Expanded(
                    child: ListView.builder(
                      itemCount: missions.length,
                      itemBuilder: (context, index) {
                        Mission mission = missions[index];
                        bool isCompleted = user.missions.any((um) => um.missionId == mission.id && um.isCompleted);

                        return Card(
                          child: ListTile(
                            leading: Image.network(mission.imageUrl),
                            title: Text(mission.title),
                            subtitle: Text('${mission.points} Poin'),
                            trailing: Icon(
                              isCompleted ? Icons.check_circle : Icons.circle,
                              color: isCompleted ? Colors.green : Colors.grey,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          }
        },
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Beranda'),
          BottomNavigationBarItem(icon: Icon(Icons.card_giftcard), label: 'Reward'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
