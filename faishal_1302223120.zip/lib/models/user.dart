class User {
  final int id;
  final String username;
  final String email;
  final int points;
  final List<UserMission> missions;

  User({
    required this.id,
    required this.username,
    required this.email,
    required this.points,
    required this.missions,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    
    var missionsJson = json['missions'] as List;
    List<UserMission> missions = missionsJson.map((m) => UserMission.fromJson(m)).toList();

    return User(
      id: json['id'] as int? ?? 0, // Jika id null, default 0
      username: json['username'] ?? '', // String kosong jika null
      email: json['email'] ?? '',
      points: json['points'] as int? ?? 0, // Default 0 jika null
      missions: missions,
    );
  }
}

class UserMission {
  final int missionId;
  final bool isCompleted;

  UserMission({
    required this.missionId,
    required this.isCompleted,
  });

  factory UserMission.fromJson(Map<String, dynamic> json) {
    
    return UserMission(
      missionId: json['mission_id'],
      isCompleted: json['is_completed'],
    );
  }
}
